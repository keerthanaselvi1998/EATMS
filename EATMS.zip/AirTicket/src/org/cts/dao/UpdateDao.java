package org.cts.dao;

import org.cts.bean.Updation;



public interface UpdateDao {
public boolean updateData(Updation e);
}
