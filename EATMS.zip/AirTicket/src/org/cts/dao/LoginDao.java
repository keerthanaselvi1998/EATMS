package org.cts.dao;

import org.cts.bean.Login;


public interface LoginDao {
public int validate(Login l);
}
