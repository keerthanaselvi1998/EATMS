package org.cts.dao;

import java.sql.ResultSet;

import org.cts.utils.ConnectConstants;
import org.cts.utils.DaoConnection;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

public class RegistrationCheckDaoImpl implements RegistrationCheckDao {

	@Override
	public boolean registrationValidation(String name) {
		
		Connection con=null;
        PreparedStatement pst=null;
        boolean b=false;
        try {
               con= (Connection) DaoConnection.getConnection(ConnectConstants.DRIVER, ConnectConstants.URL, ConnectConstants.UNAME,ConnectConstants.PWD);
               pst=(PreparedStatement) con.prepareStatement("select * from customer where name=? ");
               pst.setString(1,name);
               
               ResultSet rs= pst.executeQuery();
        
               if(rs.next())
               {
                     b=true;
               }
               else
                     b=false;
               con.close();
        } catch (Exception e) {
               e.printStackTrace();
        }
        
        return b;

	}

}
